export enum ELocalStorage {
  MY_LIST = '@my-list',
}
