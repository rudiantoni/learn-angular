export interface IListItems {
  id: string;
  checked: boolean;
  value: string;
}
