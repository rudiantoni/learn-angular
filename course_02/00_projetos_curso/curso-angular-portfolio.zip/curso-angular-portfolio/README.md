<h1 align="center">
  <img src="https://vidafullstack.com.br/wp-content/uploads/2020/07/angular.png" alt="" width="150">
  <br>
    Projeto Prático: Portfólio
  <br>
  https://troquatte.github.io/curso-angular-portfolio/browser/
</h1>

## :custard: Descrição

Use este código para fazer consultas caso tenha dúvidas no curso.

## :custard: Acesse o GhPages

<strong>Link:</strong> https://troquatte.github.io/curso-angular-portfolio/browser/

## :custard: Aprenda a subir o seu código no ghPages

<strong>Adicione ao seu projeto:</strong> ng add angular-cli-ghpages
<br>

<strong>Faça o deploy:</strong> ng deploy --base-href https://SEU_PERFIL_GITHUB.github.io/SEU_REPO_GITHUB/browser/

<strong>Exp.:</strong> ng deploy --base-href https://troquatte.github.io/curso-angular-portfolio/browser/

---

Com ♥ Dener Troquatte :wave: [Linkedin](https://www.linkedin.com/in/dener-s%C3%A3o-pedro-troquatte-ababa079/) | [Blog](https://vidafullstack.com.br/)
