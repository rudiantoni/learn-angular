export interface IKnowledge {
  src: string;
  alt: string;
}
