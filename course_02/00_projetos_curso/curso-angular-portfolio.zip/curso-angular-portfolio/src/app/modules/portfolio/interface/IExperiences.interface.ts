export interface IExperiences {
  summary: { strong: string; p: string };
  text: string;
}
