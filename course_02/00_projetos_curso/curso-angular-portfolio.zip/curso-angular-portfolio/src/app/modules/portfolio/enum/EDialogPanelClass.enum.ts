export enum EDialogPanelClass {
  PROJECTS = 'dialog-container-projects',
}
