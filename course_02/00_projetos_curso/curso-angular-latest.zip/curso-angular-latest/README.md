<h1 align="center">
  <img src="https://vidafullstack.com.br/wp-content/uploads/2020/07/angular.png" alt="" width="150">
  <br>
    Curso completo de Angular 2 + 
  <br>
  https://vidafullstack.com.br/curso-de-angular/
</h1>

## :custard: Descrição

Use este código para fazer consultas caso tenha dúvidas no curso.

---

Com  ♥  Dener Troquatte  :wave:  [Linkedin](https://www.linkedin.com/in/dener-s%C3%A3o-pedro-troquatte-ababa079/) | [Blog](https://vidafullstack.com.br/)
