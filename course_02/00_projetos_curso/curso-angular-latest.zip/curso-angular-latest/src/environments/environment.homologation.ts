export const environment = {
  env: 'hom',
  apiTask:
    'https://us-central1-curso-de-angular-api.cloudfunctions.net/app/tasks',
  img: 'http://localhost:4200/assets/',
};
