export const environment = {
  env: 'prod',
  apiTask:
    'https://us-central1-curso-de-angular-api.cloudfunctions.net/app/tasks',
  img: 'http://localhost:4200/assets/',
};
